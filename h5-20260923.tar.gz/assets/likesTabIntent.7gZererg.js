let t=!1;function c(c=uni){t=!0;try{c.switchTab({url:"/pages/likes/likes",fail:()=>{t=!1}})}catch(i){throw t=!1,i}}function i(){const c=t;return t=!1,c}export{i as c,c as o};
